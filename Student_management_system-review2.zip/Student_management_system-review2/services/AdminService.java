package services;

import java.util.List;
import models.Student;

/**
 * Placeholder for admin-specific features.
 */
public class AdminService {
    // Can be extended for admin features like resetting the system
    private StudentService studentService = new StudentService();

    public void printAllStudents() {
        List<Student> students = (List<Student>) studentService.getAllStudents();
        if (students.isEmpty()) {
            System.out.println("No students found.");
        } else {
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }
}