package services;

import java.util.ArrayList;
import java.util.List;

import models.FileHandler;
import models.Student;

/**
 * Manages student-related operations like add, update, delete, and search.
 */
public class StudentService {
    private List<Student> students;
    private FileHandler fileHandler;

    public StudentService() {
        fileHandler = new FileHandler();
        students = fileHandler.loadStudents();
    }

    public void addStudent(Student student) {
        students.add(student);
        fileHandler.saveStudents(students);
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }

    public Student findStudentById(int id) {
        for (Student student : students) {
            if (student.getId() == id) {
                return student;
            }
        }
        return null;
    }

    public void updateStudent(int id, String name, int age, double grade) {
        Student student = findStudentById(id);
        if (student != null) {
            student.setName(name);
            student.setAge(age);
            student.setGrade(grade);
            fileHandler.saveStudents(students);
        }
    }

    public void deleteStudent(int id) {
        students.removeIf(student -> student.getId() == id);
        fileHandler.saveStudents(students);
    }

    // Innovative Feature: Search students by partial name match
    public List<Student> searchByName(String searchName) {
        List<Student> results = new ArrayList<>();
        for (Student student : students) {
            if (student.getName().toLowerCase().contains(searchName.toLowerCase())) {
                results.add(student);
            }
        }
        return results;
    }

    public void saveAndExit() {
        fileHandler.saveStudents(students);
    }
}