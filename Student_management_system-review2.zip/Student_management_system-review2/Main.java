import java.util.List;
import java.util.Scanner;

import models.Student;
import services.StudentService;

// Validator import removed because it cannot be resolved.

/**
 * Main class for the student management system, providing a console-based interface.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentService studentService = new StudentService();
        // Validator validator = new Validator();
        boolean running = true;

        while (running) {
            System.out.println("\nStudent Management System");
            System.out.println("1. Add Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Search Student by Name");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1: // Add Student
                        System.out.print("Enter student ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();
                        // Skipping validation as Validator is not available
                        System.out.print("Enter student name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter student age: ");
                        int age = scanner.nextInt();
                        System.out.print("Enter student grade: ");
                        double grade = scanner.nextDouble();
                        studentService.addStudent(new Student(id, name, age, grade));
                        System.out.println("Student added successfully!");
                        break;

                    case 2: // View All Students
                        List<Student> students = studentService.getAllStudents();
                        if (students.isEmpty()) {
                            System.out.println("No students found.");
                        } else {
                            for (Student student : students) {
                                System.out.println(student);
                            }
                        }
                        break;

                    case 3: // Update Student
                        System.out.print("Enter student ID to update: ");
                        int updateId = scanner.nextInt();
                        scanner.nextLine();
                        models.Student studentToUpdate = studentService.findStudentById(updateId);
                        if (studentToUpdate == null) {
                            System.out.println("Student not found.");
                            break;
                        }
                        System.out.print("Enter new name: ");
                        String newName = scanner.nextLine();
                        System.out.print("Enter new age: ");
                        int newAge = scanner.nextInt();
                        System.out.print("Enter new grade: ");
                        double newGrade = scanner.nextDouble();
                        studentService.updateStudent(updateId, newName, newAge, newGrade);
                        System.out.println("Student updated successfully!");
                        break;
                        

                    case 5: // Search Student by Name
                        System.out.print("Enter name to search: ");
                        String searchName = scanner.nextLine();
                        List<models.Student> searchResults = studentService.searchByName(searchName);
                        if (searchResults.isEmpty()) {
                            System.out.println("No students found with name containing: " + searchName);
                        } else {
                            for (models.Student student : searchResults) {
                                System.out.println(student);
                            }
                        }
                        break;

                    case 0: // Exit
                        studentService.saveAndExit();
                        System.out.println("Exiting... Data saved.");
                        running = false;
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Invalid input. Please try again.");
                scanner.nextLine(); // Clear invalid input
            }
        }
        scanner.close();
    }
}