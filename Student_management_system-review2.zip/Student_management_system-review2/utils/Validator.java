package utils;

import java.util.List;

import models.Student;

/**
 * Validates user inputs for student attributes.
 */
public class Validator {
    public boolean isValidId(int id, List<Student> students) {
        if (id <= 0) {
            System.out.println("ID must be a positive number.");
            return false;
        }
        for (Student student : students) {
            if (student.getId() == id) {
                System.out.println("ID already exists. Please use a unique ID.");
                return false;
            }
        }
        return true;
    }

    public boolean isValidName(String name) {
        if (name == null || !name.matches("^[a-zA-Z\\s]+$")) {
            System.out.println("Name must contain only letters and spaces.");
            return false;
        }
        return true;
    }

    public boolean isValidAge(int age) {
        if (age < 5 || age > 100) {
            System.out.println("Age must be between 5 and 100.");
            return false;
        }
        return true;
    }

    public boolean isValidGrade(double grade) {
        if (grade < 0 || grade > 100) {
            System.out.println("Grade must be between 0 and 100.");
            return false;
        }
        return true;
    }
}