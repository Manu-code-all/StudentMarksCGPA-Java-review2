package models;

public class Marksheet {
    private int[] marks;

    public Marksheet(int[] marks) {
        this.marks = marks;
    }

    public int[] getMarks() {
        return marks;
    }

    public double calculateCGPA() {
        int totalPoints = 0;
        for (int mark : marks) {
            totalPoints += getGradePoint(mark);
        }
        return (double) totalPoints / marks.length;
    }

    private int getGradePoint(int mark) {
        if (mark >= 90) return 10;
        else if (mark >= 80) return 9;
        else if (mark >= 70) return 8;
        else if (mark >= 60) return 7;
        else if (mark >= 50) return 6;
        else if (mark >= 40) return 5;
        else return 0;
    }
}
